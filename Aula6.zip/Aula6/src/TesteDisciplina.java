import java.util.Scanner;

public class TesteDisciplina {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome: ");
        String n = sc.nextLine();
        System.out.print("Professor: ");
        String p = sc.nextLine();
        System.out.print("Semestre: ");
        int s = Integer.parseInt(sc.nextLine());
        System.out.print("Ofertada: ");
        boolean o = Boolean.parseBoolean(sc.nextLine());

        Disciplina disciplina = new Disciplina(n, p, s, o);

        String msg = "Nome: " + n + "\nProfessor: " + p + "\nSemestre: " + s;
        if(o == true){
            msg += "\nOfertada" + "\n";
        }
        else{
            msg += "\nNão ofertada" + "\n";
        }
        System.out.print(msg);

        System.out.print("Nome: ");
        n = sc.nextLine();
        System.out.print("Professor: ");
        p = sc.nextLine();
        System.out.print("Semestre: ");
        s = Integer.parseInt(sc.nextLine());
        System.out.print("Ofertada: ");
        o = Boolean.parseBoolean(sc.nextLine());

        disciplina.setNome(n);
        disciplina.setProfessor(p);
        disciplina.setSemestre(s);
        disciplina.setOfertada(o);

        msg = "Nome: " + n + "\nProfessor: " + p + "\nSemestre: " + s;
        if(o == true){
            msg += "\nOfertada" + "\n";
        }
        else{
            msg += "\nNão ofertada" + "\n";
        }
        System.out.print(msg);

        sc.close();
    }
}
