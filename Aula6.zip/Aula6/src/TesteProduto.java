import java.util.Scanner;

public class TesteProduto {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome: ");
        String n = sc.nextLine();
        System.out.print("Preco: ");
        double p = Double.parseDouble(sc.nextLine());
        System.out.print("Quantidade: ");
        int q = Integer.parseInt(sc.nextLine());

        Produto produto = new Produto(n, p, q);

        String msg = "Nome: " + n + "\n\"Preco: " + p + "\nQuantidade: " + q + "\n";
        System.out.print(msg);

        System.out.print("Nome: ");
        n = sc.nextLine();
        System.out.print("Preco: ");
        p = Integer.parseInt(sc.nextLine());
        System.out.print("Quantidade: ");
        q = Integer.parseInt(sc.nextLine());

        produto.setNome(n);
            produto.setPreco(p);
        produto.setQtd(q);

        msg = "Nome: " + n + "\nPreco: " + p + "\nQuantidade: " + q + "\n";
        System.out.print(msg);

        sc.close();
    }
}
