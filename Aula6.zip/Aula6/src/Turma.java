public class Turma {
    private String nome;
    private String curso;
    private int qtdAluno;
    private int serie;

    public Turma(String n, String c, int a, int s){
        nome = n;
        curso = c;
        qtdAluno = a;
        serie = s;
    }

    public String getNome(){
        return nome;
    }
    public String getCurso(){
        return curso;
    }
    public int getQtdAluno(){
        return qtdAluno;
    }
    public int getserie(){
        return serie;
    }

    public void setNome(String n){
        nome = n;
    }
    public void setCurso(String c){
        curso = c;
    }
    public void setQtdAluno(int a){
        qtdAluno = a;
    }
    public void setSerie(int s){
        serie = s;
    }
}
