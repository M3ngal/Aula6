import java.util.Scanner;

public class TesteTurma {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome: ");
        String n = sc.nextLine();
        System.out.print("Curso: ");
        String c = sc.nextLine();
        System.out.print("Quantidade de Alunos: ");
        int a = Integer.parseInt(sc.nextLine());
        System.out.print("Serie: ");
        int s = Integer.parseInt(sc.nextLine());

        Turma turma = new Turma(n, c, a, s);

        String msg = "Nome: " + n + "\nCurso: " + c + "\nQuantidade de Alunos: " + a + "\nSerie: " + s + "\n";
        System.out.print(msg);

        System.out.print("Nome: ");
        n = sc.nextLine();
        System.out.print("Curso: ");
        c = sc.nextLine();
        System.out.print("Quantidade de Alunos: ");
        a = Integer.parseInt(sc.nextLine());
        System.out.print("Serie: ");
        s = Integer.parseInt(sc.nextLine());

        turma.setNome(n);
        turma.setCurso(c);
        turma.setQtdAluno(a);
        turma.setSerie(s);

        msg = "Nome: " + n + "\nCurso: " + c + "\nQuantidade de Alunos: " + a + "\nSerie: " + s + "\n";
        System.out.print(msg);

        sc.close();
    }
}
